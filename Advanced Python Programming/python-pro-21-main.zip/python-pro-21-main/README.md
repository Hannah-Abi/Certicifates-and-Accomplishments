# python-pro-21
Python Programming 2021

This is the course for the Introduction to Programming course (TKT10002, 5 cr) and the Advanced Course in Programming (TKT10003, 5 cr) from the Department of Computer Science at the University of Helsinki.